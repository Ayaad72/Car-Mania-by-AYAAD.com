# old-htmljs-game
From my old tutorial series on how to make a HTML/JS Game
If you wanna play, go to codingap.freeiz.com/games.html
